package semesterproject;


public class SemesterProject {

    public static void main(String[] args) {
        LoadPage2 loader = new LoadPage2();

    }
}
